/*
 * Banking.java
 * 
 * Author: Leah Marshall
 * Purpose: To enhance the original banking.cpp file by encrypting user values, 
 * 			verification systems, and create an option to add users to the client list to
 * 			make this an overall more secure and user-oriented system
 * 
 * Version: 2.2.0
 * 1.0.0 Version Notes: Created the original .cpp piece
 * 2.0.0 Version Notes: Switched to Java, added an ArrayList, hashing algorithm, 
 * 						verification systems, and enhanced the menu & display systems
 * 2.1.0 Version Notes: Enhanced Comments throughout the file & added a header
 * 2.2.0 Version Notes: Enhanced Intent & Decision comments
 * Last Edited: 4/5/24
 * 
 * NOTE FOR USERS TRYING TO USE THIS PROGRAM:
 * THE USERNAME IS ADMIN
 * THE PASSWORD IS 1234567
 */

import java.util.Scanner;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class Banking {
	
	// An array list is now used to store Client data
	private static final ArrayList<BankingClients> clientList = new ArrayList<>();
	
	// MD5 (Message Digest) Hashing Algorithm 
	// Encrypts the PASSWORD
	public static String doPasswordHashing (String password) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(password.getBytes());
			byte[] resultByteArray = messageDigest.digest();
			StringBuilder sb = new StringBuilder();
			
			for(byte b : resultByteArray) {
				sb.append(String.format("%02x", b));
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	// For this I found out the hashedPassword value of "1234567", which is the password
	// to the system, and used it to verify against the hashed version of what the user input
	public static int checkPassword (String hashedPassword) {
		if(hashedPassword.equals("fcea920f7412b5da7be0cf42b8c93759")) {
			System.out.println("Password is Correct.");
		} else {
			System.out.println("Wrong password. Exiting Program.");
			System.exit(0);
		}
		return 0;
	}
	
	// MD5 (Message Digest) Hashing Algorithm 
	// Encrypts the USERNAME 
	public static String doUsernameHashing (String username) {
			try {
				MessageDigest messageDigest = MessageDigest.getInstance("MD5");
				messageDigest.update(username.getBytes());
				byte[] resultByteArray = messageDigest.digest();
				StringBuilder sb = new StringBuilder();
				
				for(byte b : resultByteArray) {
					sb.append(String.format("%02x", b));
				}
				return sb.toString();
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			return "";
		}
		
	// For this I found out the hashedUsername value of "admin", and verified it
	// similar to the checkPassword method 
	public static int checkUsername (String hashedUsername) {
		if(hashedUsername.equals("21232f297a57a5a743894a0e4a801fc3")) {
			System.out.println("Username is Correct.");
		} else {
			System.out.println("Wrong Username. Exiting Program.");
			System.exit(0);
		}
		return 0;
	}
		
	// Added a method which allows you to add to the client list & gets rid of the previous structure
	public static void newClients() {
		
		// Takes in user input & verifies if they're on the list already
		Scanner scnr = new Scanner(System.in);
		System.out.println("What is the new Client's first name?");
		String firstName = scnr.nextLine();
		
		System.out.println("What is the new Client's last name?");
		String lastName = scnr.nextLine();
		
		for(BankingClients bankingClients : clientList) {
			if(bankingClients.getFirstName().equalsIgnoreCase(firstName) && bankingClients.getLastName().equalsIgnoreCase(lastName)) {
				System.out.println("This person is already on the list!");
				return;
			}
		}
		
		System.out.println("What is their Service Choice? Brokerage or Retirement?");
		String serviceChoice = scnr.nextLine();
		
		// Adds new client to the array list
		BankingClients bankingClients = new BankingClients(firstName, lastName, serviceChoice);
		clientList.add(bankingClients);
		
		System.out.println("The client was added to the list.");
		System.out.println("Returning back to the Main Menu...");
		System.out.println("");
		System.out.println("");
	}
	
	// Simply displays the client, the only change that occurs here 
	// is HOW the data is displayed (A title + descriptions of what is printed)
	public static void displayClients() {
		System.out.println("List of Clients");
		System.out.println("--------------------------------");
		for (BankingClients bankingClients : clientList) {
			printClient(bankingClients);
		}
	}
	
	public static void printClient(BankingClients bankingClients) {
		System.out.println("First name: " + bankingClients.getFirstName() + "\n" +
							"Last name: " + bankingClients.getLastName() + "\n" + 
							"Service Choice: " + bankingClients.getServiceChoice() + "\n");
	}
	
	// The original main method had the client structure inside of it. 
	// I took the structure out of the main method, and created a new class to 
	// hold the necessary functions needed for it. 
	// The new main method only includes what is necessary for the menu to run properly. 
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		String username;
		String password;
		String hashedPassword;
		String hashedUsername;
		int choice; 
		
		System.out.println("Hello, Welcome to Leah's Improved Investment Banking System!");
		System.out.println("************************************************************");
		System.out.println("Enter your username: ");
		username = scnr.nextLine();
		System.out.println("Enter your password: ");
		password = scnr.nextLine();
		
		// These are just tests to make sure the hashing algorithm worked properly
		//System.out.println("Hashed Username: " + doUsernameHashing(username));
		//System.out.println("Hashed Password: " + doPasswordHashing(password));

		hashedPassword = doPasswordHashing(password);
		hashedUsername = doUsernameHashing(username);
		
		checkPassword(hashedPassword);
		checkUsername(hashedUsername);
		
		while (true) {
			System.out.println("What would you like to do?");
			System.out.println("(Enter 1) DISPLAY the client list.");
			System.out.println("(Enter 2) ADD TO the client list.");
			System.out.println("(Enter 3) EXIT the program.");
			choice = scnr.nextInt();
			
			if(choice == 1) {
				System.out.println("");
				displayClients();
				System.out.println("");
				System.out.println("Returning back to the Main Menu...");
			} else if (choice == 2) {
				System.out.println("Entering the Adding Clients program...");
				System.out.println("*************************");
				System.out.println("");
				newClients();
				System.out.println("Returning back to the Main Menu...");
			} else if (choice == 3) {
				System.out.println("Exiting the program.");
				break;
			} else {
				System.out.println("Invalid Choice. Please try again.");
				return;
			}
		}
		System.exit(0);
	}	
}

