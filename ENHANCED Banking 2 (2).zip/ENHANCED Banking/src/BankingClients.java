/*
 * BankingClients.java
 * 
 * Author: Leah Marshall
 * Purpose: To be used with the array list in Banking.java
 * 			This class constructs variables to hold the data needed for the ClientList,
 * 			creates Getters and Setters which can be used to access these variables. 
 * 
 * Version: 1.2.0
 * 1.0.0 Version Notes: Created the original BankingClients.java file for Banking.java
 * 						including the constructor, getters, and setters. 
 * 1.1.0 Version Notes: Enhanced Comments throughout the file & added a header
 * 1.2.0 Version Notes: Enhanced header's content
 * Last Edited: 4/4/24
 */

public class BankingClients {
	private String firstName;
	private String lastName;
	private String serviceChoice;
	
	// Basic constructor class for firstName, lastName, and serviceChoice
	public BankingClients(String firstName, String lastName, String serviceChoice) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.serviceChoice = serviceChoice;
	}
	
	// Basic getter methods for each variable
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getServiceChoice() {
		return serviceChoice;
	}
	
	// Basic setter methods for each variable 
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setServiceChoice(String serviceChoice) {
		this.serviceChoice = serviceChoice;
	}
}
