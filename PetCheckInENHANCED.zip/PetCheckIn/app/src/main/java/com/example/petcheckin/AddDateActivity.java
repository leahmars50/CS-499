/************************************************************************************
   File: AddDateActivity.java
   Author: Leah Marshall
   Purpose: To gather a pet's information in order to put into the PetDatabase
   Version: 1.0.0
 *************************************************************************************/
package com.example.petcheckin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddDateActivity extends AppCompatActivity {

    EditText petName, petBreed, daysStay, grooming;
    Button requestButton;

    //creates variables which hold information that is gathered via the .xml file
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_date);

        petName = findViewById(R.id.petName);
        petBreed = findViewById(R.id.petBreed);
        daysStay = findViewById(R.id.daysStay);
        grooming = findViewById(R.id.grooming);

        //creates a usage for the button in the .xml file
        requestButton = findViewById(R.id.requestButton);
        requestButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                PetDatabase myDB = new PetDatabase(AddDateActivity.this);
                myDB.addItem(petName.getText().toString().trim(),
                        petBreed.getText().toString().trim(),
                        Integer.parseInt(daysStay.getText().toString().trim()),
                        grooming.getText().toString().trim());
            }
        });
    }
}