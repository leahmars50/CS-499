/************************************************************************************
 File: LoginActivity.java
 Author: Leah Marshall
 Purpose: To gather a user's information in order to verify against the UserDatabase
 Version: 1.0.0
 *************************************************************************************/
package com.example.petcheckin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.petcheckin.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding binding;
    UserDatabase userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userDatabase = new UserDatabase(this);

        //creates usage for the login button on the .xml file
        binding.loginButton.setOnClickListener(new View.OnClickListener() {
            //essentially, on click of the button, get the email and password and turn it into strings that are readable
            @Override
            public void onClick(View v) {
                String email = binding.loginEmail.getText().toString();
                String password = binding.loginPassword.getText().toString();

                //errors & exception handlers
                if (email.isEmpty() || password.isEmpty())
                    Toast.makeText(LoginActivity.this, "Fields cannot be empty.", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkCredentials = userDatabase.checkEmailPassword(email, password);

                    if (checkCredentials){
                        Toast.makeText(LoginActivity.this, "Logged in successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // if you hit the redirect button, sends the user to the signup screen
        binding.signupRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

    }
}