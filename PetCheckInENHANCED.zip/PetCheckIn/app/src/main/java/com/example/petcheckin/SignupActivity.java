/************************************************************************************
 File: SignupActivity.java
 Author: Leah Marshall
 Purpose: To gather a user's information in order to put into the UserDatabase
 Version: 1.0.0
 *************************************************************************************/
package com.example.petcheckin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.petcheckin.databinding.ActivitySignupBinding;

public class SignupActivity extends AppCompatActivity {

    ActivitySignupBinding binding;
    UserDatabase userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userDatabase = new UserDatabase(this);

        //gives the signup button a usage
        binding.signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //gets the email and password the user put in and turns them into readable strings
                String email = binding.signupEmail.getText().toString();
                String password = binding.signupPassword.getText().toString();
                String confirmPassword = binding.signupConfirmPassword.getText().toString();

                // exception handlers, if the user doesn't exist already then adds them to the database
                if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty())
                    Toast.makeText(SignupActivity.this, "Fields cannot be empty.", Toast.LENGTH_SHORT).show();
                else {
                    if (password.equals(confirmPassword)){
                        Boolean checkUserEmail = userDatabase.checkEmail(email);

                        if (!checkUserEmail) {
                            Boolean insert = userDatabase.insertData(email, password);

                            if (insert){
                                Toast.makeText(SignupActivity.this, "Signed up successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(SignupActivity.this, "Signup Failed.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(SignupActivity.this, "User already exists. Please login instead.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SignupActivity.this, "Invalid password.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // if the user hits the "login redirect" button, takes them to the login page
        binding.loginRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}